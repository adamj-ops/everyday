import Contact from '@/components/sections/contact';

export default function ContactPage() {
  return <Contact />;
}
